package com.ads.chicagocrime;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TimeSeries {
	
	private static final Logger logger = LoggerFactory.getLogger(TimeSeries.class);
	
	@RequestMapping(value = "/prediction.htm", method = RequestMethod.POST)
	public ModelAndView predictive(HttpServletRequest request, HttpServletResponse response) {
		
		logger.info("Time series POST method!");
		String district = request.getParameter("district");
		String month = request.getParameter("month");
		String year = request.getParameter("year");
		String date=month+"/"+"1"+"/"+year;
		
		String districtName="";
		String monthName="";
		
		if(district.equalsIgnoreCase("1")){
			districtName="Central";
		}
		else if(district.equalsIgnoreCase("2")){
			districtName="Wentworth";
		}
		else if(district.equalsIgnoreCase("3")){
			districtName="Grand Crossing";
		}
		else if(district.equalsIgnoreCase("4")){
			districtName="South Chicago";
		}
		else if(district.equalsIgnoreCase("5")){
			districtName="Calumet";
		}
		else if(district.equalsIgnoreCase("6")){
			districtName="Grehsam";
		}
		else if(district.equalsIgnoreCase("7")){
			districtName="Englewood";
		}
		else if(district.equalsIgnoreCase("8")){
			districtName="Chicago Lawn";
		}
		else if(district.equalsIgnoreCase("9")){
			districtName="Deering";
		}
		else if(district.equalsIgnoreCase("10")){
			districtName="Ogden";
		}
		else if(district.equalsIgnoreCase("12")){
			districtName="Near West";
		}
		else if(district.equalsIgnoreCase("11")){
			districtName="Harrison";
		}
		else if(district.equalsIgnoreCase("14")){
			districtName="Shakespeare";
		}
		else if(district.equalsIgnoreCase("15")){
			districtName="Austin";
		}
		else if(district.equalsIgnoreCase("16")){
			districtName="Jefferson Park";
		}
		else if(district.equalsIgnoreCase("17")){
			districtName="Albany Park";
		}
		else if(district.equalsIgnoreCase("18")){
			districtName="Near North";
		}
		else if(district.equalsIgnoreCase("19")){
			districtName="Town Hall";
		}
		else if(district.equalsIgnoreCase("20")){
			districtName="Lincoln";
		}
		else if(district.equalsIgnoreCase("22")){
			districtName="Morgan Park";
		}
		else if(district.equalsIgnoreCase("24")){
			districtName="Rogers Park";
		}
		else if(district.equalsIgnoreCase("25")){
			districtName="Grand Central";
		}
		
		if(month.equalsIgnoreCase("1")){
			monthName="January";
		}
		else if(month.equalsIgnoreCase("2")){
			monthName="February";
		}
		else if(month.equalsIgnoreCase("3")){
			monthName="March";
		}
		else if(month.equalsIgnoreCase("4")){
			monthName="April";
		}
		else if(month.equalsIgnoreCase("5")){
			monthName="May";
		}
		else if(month.equalsIgnoreCase("6")){
			monthName="June";
		}
		else if(month.equalsIgnoreCase("7")){
			monthName="July";
		}
		else if(month.equalsIgnoreCase("8")){
			monthName="August";
		}
		else if(month.equalsIgnoreCase("9")){
			monthName="September";
		}
		else if(month.equalsIgnoreCase("10")){
			monthName="October";
		}
		else if(month.equalsIgnoreCase("11")){
			monthName="November";
		}
		else if(month.equalsIgnoreCase("12")){
			monthName="December";
		}
		
		
		String count=timeSeriesPrediction(district,date);
		
		System.out.println(count.replaceAll("]", ""));
		ModelAndView mv = new ModelAndView("PredictionOutput");
		mv.addObject("count", count.replaceAll("]", ""));
		mv.addObject("district",districtName);
		mv.addObject("month", monthName);
		mv.addObject("year", year);
		return mv;
	}

	private String timeSeriesPrediction(String district, String date) {
		// TODO Auto-generated method stub
		
		HttpPost post = new HttpPost();
		HttpClient client;
		StringEntity entity;
		String apikey = "";
		String count="0";

		try {
			if (district.equalsIgnoreCase("1")) {
				logger.info("Distict 1 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/4c029af3be234c93810c7f2776a62150/execute?api-version=2.0&details=true");
				apikey = "isi+iw4zMbq+2LFjtcjrpyMucocw3ZK18UAaXsCDwJGfIjVO6WNWFCRmuowxhEMAYhvlUqZWNSFub+WVix/xnw==";
			}
			else if (district.equalsIgnoreCase("2")) {
				logger.info("Distict 2 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/e8c825a8451642d69be25add49248be4/execute?api-version=2.0&details=true");
				apikey = "RNbWoTUezZSEqTvd6vjI4/IR2YPL5b2vBKnBaO9KddwwwcPgQDoZAvA459aG3c5uCb2Yat9sBmrTsQG5xcdaqw==";
			}
			else if (district.equalsIgnoreCase("3")) {
				logger.info("Distict 3 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/d4d8d5a53d3e4ed1a055b10755d7b714/execute?api-version=2.0&details=true");
				apikey = "SpF1cdxoXME68LgSUjiQTwZxDbQFb7DmIY70Y3UtGdmjSsiNfZdQalPoHdXg3QLEwnu6foJ2oTD8I7s22D6LPg==";
			}
			else if (district.equalsIgnoreCase("4")) {
				logger.info("Distict 4 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/d62cf70951754caba0ea13de72b17ee0/execute?api-version=2.0&details=true");
				apikey = "OIa8BY9UrSBKBUIh78beNNAtbqZMKytLjqO9mOGg4JbNOzJmM7sX7khqkAMU7LQzngD7uzpofmAdUOfV4eScpg==";
			}
			else if (district.equalsIgnoreCase("5")) {
				logger.info("Distict 5 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/ae29cbb7c6de45598baf3311713e620e/execute?api-version=2.0&details=true");
				apikey = "kDpG5gjJNVRoBg0pnSFeyaVtnsjgrwH1e8BNphDw/48iFM6Z7sS0Y3pMVwrwypUpF1R3nblm4E/11t5Pc2kMtA==";
			}
			else if (district.equalsIgnoreCase("6")) {
				logger.info("Distict 6 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/8a4547ed601c4c4096004c92efc10568/execute?api-version=2.0&details=true");
				apikey = "jcCYrrRp/TGfbNVZqwFgNeM18XNhgB14eRapLPkv1bCkQVhhZ/no+g+IH7QP8MUkiz8/Id19hU5uJYbBDyo4tg==";
			}
			else if (district.equalsIgnoreCase("7")) {
				logger.info("Distict 7 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/e4e39466198541f6889b8331f3420dd7/execute?api-version=2.0&details=true");
				apikey = "FG2Ga4bbR6Z4/7boVUkVDqWRW733gLLEv+pcNSvvvJUcbV1iMio2Ng8kJUHdgUTO9BkGRQRy+WHm5+fVDAglkQ==";
			}
			else if (district.equalsIgnoreCase("8")) {
				logger.info("Distict 8 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/2742133bfe1d476087d11287bcb44689/execute?api-version=2.0&details=true");
				apikey = "MB0TIlxXRWnEK57wvjiKmjkvqXvP2+49F5A4DvxNu49z9tf8rBqjmiKdbILLGz9rJUVQgHMqVVmwbPaOO5IV7Q==";
			}
			else if (district.equalsIgnoreCase("9")) {
				logger.info("Distict 9 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/9dd8aac5c5864e83bd1871122a0cbd34/execute?api-version=2.0&details=true");
				apikey = "k4tnHpHbrHcgstRIKmMAgMpZT9WhoT+q3p44uLdbrHJZrmtne7KaOrJEqI/Ye/ELPKI7C5ptQ0pmj+BzHBs6IA==";
			}
			else if (district.equalsIgnoreCase("10")) {
				logger.info("Distict 10 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/792c918eb7bd4fb5b6ef852550c26880/execute?api-version=2.0&details=true");
				apikey = "JiRjpKzKRaf04GoCEMzbFdGaM0ub9a6ES/HXsfcLWqd26piZX3s5ETa62McmkmTJyUOVoydc8rQMaBdcMyoBog==";
			}
			else if (district.equalsIgnoreCase("11")) {
				logger.info("Distict 11 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/23c37c4961334f2d96e860e95f02ae7b/execute?api-version=2.0&details=true");
				apikey = "vm+Yr5KyaGX+PpqHtDb6+/itBOChOHuJNeAFtQk/tVnXdBd7ik8eRoPgVHDTwHviL+3Ft/6TswN1k8gL9RPMGQ==";
			}
			else if (district.equalsIgnoreCase("12")) {
				logger.info("Distict 12 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/7fb8b27b7afa46098e2921082187e59a/execute?api-version=2.0&details=true");
				apikey = "uTv0a8JI8iLUFZt6FwZ9LgAVakSNZNhFjNIjq61q7ra0EX8qYJ8v/CLrpTBW1BioCY8SzhHYumx6/v3XfB80CA==";
			}
			else if (district.equalsIgnoreCase("14")) {
				logger.info("Distict 14 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/5a97072aeeab451e9ad1767c4249e462/execute?api-version=2.0&details=true");
				apikey = "qdoEEDiwVbR6dXsWBXaT3XDMAUEDiSOck2Z/okWrzybzdt3jc+J+gVlL5ZQO3D3ldttTvuSssPdkSekQ9PTI0g==";
			}
			else if (district.equalsIgnoreCase("15")) {
				logger.info("Distict 15 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/087975aa5b6d4a7a9bc8ae192460a2d0/execute?api-version=2.0&details=true");
				apikey = "G8YxVR+TpMVT2OQO2iuBrKuH9Qr0MFgFcyo2ivgdOl+mpy1zhmAiGExA5yv9kReMaG4GH9MuNEjNBvL1y7DeyQ==";
			}
			else if (district.equalsIgnoreCase("16")) {
				logger.info("Distict 16 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/4071b044baa74378a77cac848c2c732a/execute?api-version=2.0&details=true");
				apikey = "QBoSx/XEFFMOYvaE8SbI/mh9PYOPkmz7dI7Tfyd3xVAy7UuWg4dMQ/xUA57sreZHgXqlD/07TJYrbJ30nmbD3Q==";
			}
			else if (district.equalsIgnoreCase("17")) {
				logger.info("Distict 17 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/9cc988909d704cdf98d9632f1f9ac644/execute?api-version=2.0&details=true");
				apikey = "k9Prk2dWKZ2z5VcWtxweRGLIotUjfFO+D80aAi/aEhwLT8/rAfsEntHMHF/ghNqWQALGmi+W44jhHYb4R9/kJw==";
			}
			else if (district.equalsIgnoreCase("18")) {
				logger.info("Distict 18 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/3ea521e5259b400792f639d012d21b9e/execute?api-version=2.0&details=true");
				apikey = "wG9nsfO0Rflt+0HFUifuNl6/0tjTpCTEfuK6wGQNEvItG22EZZMgrmrpJ0Jx/eK1+v43fUNjBBChuNvKA5O6Uw==";
			}
			else if (district.equalsIgnoreCase("19")) {
				logger.info("Distict 19 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/d743c6cc925441779e1ca401837bfe0b/execute?api-version=2.0&details=true");
				apikey = "CctQHYU55oSKQNTbKpMrNI5SaiNN2h4Q2wHvkzvXRXwTbHa7wy+fRCbhF5mHMnXA1Z4cf1hOAKigOQJjQjwWFw==";
			}
			else if (district.equalsIgnoreCase("20")) {
				logger.info("Distict 20 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/7e5a96ccb53a4db98826390aa1df61f9/execute?api-version=2.0&details=true");
				apikey = "f5MVbMEsL299n1kPYY0u8SZGkaPDSie+tDWRvbuF4TAwzvUDZuzhXV+VcotEbmo+9QyiyJGjLY7+tEPXNqk38A==";
			}
			else if (district.equalsIgnoreCase("22")) {
				logger.info("Distict 22 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/57521b9b7acc403abac3c74aaa478e87/execute?api-version=2.0&details=true");
				apikey = "aI27D2rS2wQuJSVwtdQVnM9GmFwI8jRvK6p4oZ4OYMe9E4n96O8B7O4M82JAiuhjqQiayJ5yKcs8zgrsrbrNpw==";
			}
			else if (district.equalsIgnoreCase("24")) {
				logger.info("Distict 24 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/bae37b3f531e40a2a5e83cfa2f39cbc5/execute?api-version=2.0&details=true");
				apikey = "bNXPOTLT7EoFIMt4iJ7UMYi0J7Rw5kCScMXJ+BbFHc5iKrd9FlvW2gZiRhfC63GSjH1cPFQgWrWNDeJL7+bwCg==";
			}
			else if (district.equalsIgnoreCase("25")) {
				logger.info("Distict 25 called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/3ee92727803e492b927d1cdc4bea0e1d/services/dd83fada902a4090b32fc6efee96d4e7/execute?api-version=2.0&details=true");
				apikey = "fhw54jMj8PByuRy7C8STUxMk1Fs4waUQ5TKTxKfyQSu/txWVoum5bYEiztaOvFk+u8uOjvbaNKNy7H45LtCxfA==";
			}
			client = HttpClientBuilder.create().build();

			// setup output message by copying JSON body into
			// apache StringEntity object along with content type
			entity = new StringEntity("{}");
			// add HTTP headers
			post.setHeader("Content-type", "application/json");
			post.setHeader("Accept", "application/json");
			// set Authorization header based on the API key

			post.setHeader("Authorization", ("Bearer " + apikey));
			post.setEntity(entity);
			HttpResponse authResponse = client.execute(post);

			String json = EntityUtils.toString(authResponse.getEntity());
			JSONObject jsonObject = new JSONObject(json);
			JSONArray jsonobj = jsonObject.getJSONObject("Results").getJSONObject("output1").getJSONObject("value")
					.getJSONArray("Values");

			//System.out.println(jsonobj);
			
			int len=jsonobj.length();
			
			
			for(int i=0;i<len;i++){
				String j = jsonobj.get(i).toString();
				String x = j.replaceAll("\"", "");
				String values[] = x.split(",");
				if(values[0].contains(date)){
					count=values[1];
					break;
				}
				
			}
			
			
			//String x = j.replaceAll("\"", "");
			//String values[] = x.split(",");
			
			
		}catch (Exception e) {

			return null;
		}
		
		return count;
	}

}
