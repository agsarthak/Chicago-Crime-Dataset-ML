/**
 * 
 */
BarChart = function(_parentElement) {
	// defines tants
	this.parentElement = _parentElement;
}

BarChart.prototype.initVis = function(_year) {

	var filter = _year;
	
	var margin = {
			top : 20,
			right : 20,
			bottom : 70,
			left : 40
		}, width = 600 - margin.left - margin.right, height = 300 - margin.top
				- margin.bottom;

	var x = d3.scale.ordinal().rangeRoundBands([ 0, width ], .05);

	var y = d3.scale.linear().range([ height, 0 ]);

	var xAxis = d3.svg.axis().scale(x).orient("bottom");

	var yAxis = d3.svg.axis().scale(y).orient("left");
	
	var svg = this.parentElement.append("svg")
	.attr("width",width + margin.left + margin.right)
	.attr("height",height + margin.top + margin.bottom)
	.append("g")
	.attr("transform","translate(" + margin.left + "," + margin.top + ")");
	
	d3.csv("resources/data/TotalVsArrest.csv", function(error, data) {

		data = data.filter(function(row) {
			return row['District'] == filter
		})

		data.forEach(function(d) {
			d.District = +d.District;
			d.Year = +d.Year;
			d.IDCount = +d.IDCount;
			d.ArrestCount = +d.ArrestCount;
		});
		
		x.domain(data.map(function(d) {
			return d.Year;
		}));
		
		y.domain([ 0, d3.max(data, function(d) {
			return d.IDCount;
		}) ]);
		
		 svg.append("text")
	        .attr("x", (width / 2))             
	        .attr("y", 0 - (margin.top / 2))
	        .attr("text-anchor", "middle")  
	        .style("font-size", "16px") 
	        .style("text-decoration", "underline")  
	        .text("Case Registered % vs Arrest");
		
		svg.append("g").attr("class", "x axis")
		.attr("transform","translate(0," + height + ")").call(xAxis);

		svg.append("g").attr("class", "y axis").call(yAxis).append("text")
				.attr("transform", "rotate(-90)").attr("y", 6).attr("dy",
						".71em").style("text-anchor", "end").text("Values");
		
		var g = svg.selectAll(".bars")
        .data(data)
        .enter().append("g")
        
      g.append("rect")
        .attr("class", "bar1").style("fill",
		"orange")
        .attr("x", function(d) {
          return x(d.Year) + 10; // center it
        })
        .attr("width", x.rangeBand() - 20) // make it slimmer
        .attr("y", function(d) {
          return y(d.IDCount);
        })
        .attr("height", function(d) {
          return height - y(d.IDCount);
        });
      
      g.append("rect")
        .attr("class", "bar2").style("fill",
		"grey")
        .attr("x", function(d) {
          return x(d.Year);
        })
        .attr("width", x.rangeBand())
        .attr("y", function(d) {
          return y(d.ArrestCount);
        })
        .attr("height", function(d) {
          return height - y(d.ArrestCount);
        });

	});

}

BarChart.prototype.updateVis = function(_year) {
	var filter = _year;
	
	var margin = {
			top : 20,
			right : 20,
			bottom : 70,
			left : 40
		}, width = 600 - margin.left - margin.right, height = 300 - margin.top
				- margin.bottom;

	var x = d3.scale.ordinal().rangeRoundBands([ 0, width ], .05);

	var y = d3.scale.linear().range([ height, 0 ]);

	var xAxis = d3.svg.axis().scale(x).orient("bottom");

	var yAxis = d3.svg.axis().scale(y).orient("left");
	
	var svg = d3.select("#barChart svg g");
	
	d3.csv("resources/data/TotalVsArrest.csv", function(error, data) {

		data = data.filter(function(row) {
			return row['District'] == filter
		})

		data.forEach(function(d) {
			d.District = +d.District;
			d.Year = +d.Year;
			d.IDCount = +d.IDCount;
			d.ArrestCount = +d.ArrestCount;
		});
		
		x.domain(data.map(function(d) {
			return d.Year;
		}));
		
		y.domain([ 0, d3.max(data, function(d) {
			return d.IDCount;
		}) ]);
		var g = svg.selectAll(".bars")
        .data(data)
        .enter().append("g");
        
		var bars = svg.selectAll("rect").data(data, function(d) { return d.Year; });
		
		// Add
		g.append("rect")
        .attr("class", "bar1").style("fill",
		"orange")
        .attr("x", function(d) {
          return x(d.Year) + 10; // center it
        })
        .attr("width", x.rangeBand() - 20) // make it slimmer
        .attr("y", function(d) {
          return y(d.IDCount);
        })
        .attr("height", function(d) {
          return height - y(d.IDCount);
        });
		
		// Add
		g.append("rect")
        .attr("class", "bar2").style("fill",
		"grey")
        .attr("x", function(d) {
          return x(d.Year);
        })
        .attr("width", x.rangeBand())
        .attr("y", function(d) {
          return y(d.ArrestCount);
        })
        .attr("height", function(d) {
          return height - y(d.ArrestCount);
        });
		
		d3.selectAll("g.x.axis").transition().call(xAxis);

		d3.selectAll("g.y.axis").transition().call(yAxis);

		g.transition().attr("x", function(d) {
            return x(d.Year);
        }).attr("width", x.rangeBand()).attr("y", function(d) {
			return y(d.IDCount);
		}).attr("height", function(d) {
			return height - y(d.IDCount);
		});
		
		
		bars.exit().transition().duration(5).attr("x", -x.rangeBand()).remove();
		
	});
}