/**
 * 
 */
PieChart = function(_parentElement) {
	// defines tants
	this.parentElement = _parentElement;
}

PieChart.prototype.initVis = function(_year) {

	var filter = _year;
	
	var margin = {
			top : 20,
			right : 20,
			bottom : 70,
			left : 40
		}, width = 600 - margin.left - margin.right, height = 500 - margin.top
				- margin.bottom;
	
	//var width = 960;
	//var height = 500;
	var radius = 200;

	var svg = this.parentElement.append("svg")
		.attr("width", width + margin.left + margin.right)
		.attr("height", height + margin.top + margin.bottom)
		.append("g")
		.attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

	var arc = d3.svg.arc()
			.outerRadius(radius)
			.innerRadius(30);
	
	var color = d3.scale.ordinal()
	  .domain(["ARSON", "ASSAULT", "BATTERY","BURGLARY","CONCEALED CARRY LICENSE VIOLATION","CRIM SEXUAL ASSAULT",
		  "CRIMINAL DAMAGE","CRIMINAL TRESPASS","DECEPTIVE PRACTICE","GAMBLING","HOMICIDE","HUMAN TRAFFICKING",
		  "INTERFERENCE WITH PUBLIC OFFICER","INTIMIDATION","KIDNAPPING","LIQUOR LAW VIOLATION","MOTOR VEHICLE THEFT",
		  "NARCOTICS","NON - CRIMINAL","NON-CRIMINAL","OBSCENITY","OFFENSE INVOLVING CHILDREN","OTHER NARCOTIC VIOLATION","OTHER OFFENSE",
		  "PROSTITUTION","PUBLIC INDECENCY","PUBLIC PEACE VIOLATION","ROBBERY","SEX OFFENSE","STALKING","THEFT"])
	  .range(["#65C400", "#2290EE", "#FFC096","#5e5e5e","#CCFFFF","#00CC00",
		  "#CC0000","#FF6666","#6666FF","#00CC36","#655e00","#904a79",
		  "#90cc79","#f5cc79","#f50979","#1509f7","#158ff7",
		  "#158f34","#15d834","#f57940","#f516c6","#f51606","#d7b406","#86dd60",
		  "#3dddeb","#d299eb","#f40cfb","#f48816","#0f8816","#0f88bf","#f848bf"]);

	var pie = d3.layout.pie()
			.sort(null)
			.value(function(d){ return d.IDcount; });
	

	
	d3.csv("resources/data/PrimaryType.csv", function(error, data) {

		data = data.filter(function(row) {
			return row['District'] == filter
		})

		data.forEach(function(d) {
			d.IDcount = +d.IDcount;
		});
		
		svg.append("text")
        .attr("x", -130)             
        .attr("y", -190)
        .attr("text-anchor", "middle")  
        .style("font-size", "16px") 
        .style("text-decoration", "underline")  
        .text("Primary Types");

	
		var g = svg.selectAll(".fan")
		.data(pie(data))
		.enter()
		.append("g")
		.attr("class", "fan")
		
		var count = 0;

g.append("path")
	.attr("d", arc)
	.attr("id", function(d) { return "arc-" + (count++); })
	.attr('fill', function(d, i) {
     return color(d.data.PrimaryType);
   });
	
	
	count = 0;
	  var legend = svg.selectAll(".legend")
	      .data(data).enter()
	      .append("g").attr("class", "legend")
	      .attr("legend-id", function(d) {
	          return count++;
	      })
	      .attr("transform", function(d, i) {
	          return "translate(-60," + (-200 + i * 20) + ")";
	      })
	      .on("click", function() {
	          var arc = d3.select("#arc-" + $(this).attr("legend-id"));
	          arc.style("opacity", 0.3);
	          setTimeout(function() {
	              arc.style("opacity", 1);
	          }, 1000);
	      });
	  
	  legend.append("rect")
	      .attr("x", width/2 )
	      .attr("width", 18).attr("height", 18)
	      .style("fill", function(d) {
	          return color(d.PrimaryType);
	      });
	  legend.append("text").attr("x", width/2+20)
	      .attr("y", 9).attr("dy", ".5em")
	      .style("text-anchor", "start").text(function(d) {
	          return d.PrimaryType;
	      });
	  
	});

}

PieChart.prototype.updateVis = function(_year) {
	var filter = _year;
	
	var margin = {
			top : 20,
			right : 20,
			bottom : 70,
			left : 40
		}, width = 600 - margin.left - margin.right, height = 500 - margin.top
				- margin.bottom;
	
	//var width = 960;
	//var height = 500;
	var radius = 200;
	
	var svg = d3.select("#pieChart svg g");

	var arc = d3.svg.arc()
			.outerRadius(radius)
			.innerRadius(30);
	
	var color = d3.scale.ordinal()
	  .domain(["ARSON", "ASSAULT", "BATTERY","BURGLARY","CONCEALED CARRY LICENSE VIOLATION","CRIM SEXUAL ASSAULT",
		  "CRIMINAL DAMAGE","CRIMINAL TRESPASS","DECEPTIVE PRACTICE","GAMBLING","HOMICIDE","HUMAN TRAFFICKING",
		  "INTERFERENCE WITH PUBLIC OFFICER","INTIMIDATION","KIDNAPPING","LIQUOR LAW VIOLATION","MOTOR VEHICLE THEFT",
		  "NARCOTICS","NON - CRIMINAL","NON-CRIMINAL","OBSCENITY","OFFENSE INVOLVING CHILDREN","OTHER NARCOTIC VIOLATION","OTHER OFFENSE",
		  "PROSTITUTION","PUBLIC INDECENCY","PUBLIC PEACE VIOLATION","ROBBERY","SEX OFFENSE","STALKING","THEFT"])
	  .range(["#65C400", "#2290EE", "#FFC096","#5e5e5e","#CCFFFF","#00CC00",
		  "#CC0000","#FF6666","#6666FF","#00CC36","#655e00","#904a79",
		  "#90cc79","#f5cc79","#f50979","#1509f7","#158ff7",
		  "#158f34","#15d834","#f57940","#f516c6","#f51606","#d7b406","#86dd60",
		  "#3dddeb","#d299eb","#f40cfb","#f48816","#0f8816","#0f88bf","#f848bf"]);

	var pie = d3.layout.pie()
			.sort(null)
			.value(function(d){ return d.IDcount; });
	

	
	d3.csv("resources/data/PrimaryType.csv", function(error, data) {

		data = data.filter(function(row) {
			return row['District'] == filter
		})

		data.forEach(function(d) {
			d.IDcount = +d.IDcount;
		});

		var fan= svg.selectAll(".fan").data(data, function(d) { return d.IDcount; });
		var legend= svg.selectAll(".legend").data(data);;
		fan.exit().remove();
		legend.exit().remove();
		
		var count = 0;
	
		var g = svg.selectAll(".fan")
		.data(pie(data))
		.enter()
		.append("g")
		.attr("class", "fan")

g.append("path")
	.attr("d", arc)
	.attr("id", function(d) { return "arc-" + (count++); })
	.attr('fill', function(d, i) {
     return color(d.data.PrimaryType);
   });


	});
	
	

}